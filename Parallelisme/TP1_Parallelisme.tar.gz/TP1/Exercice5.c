#include <omp.h>
#include <stdio.h>
#include<math.h>

typedef struct{
	double x,y;
} complex;

const int OMP_NUM_THREADS = 1;

complex add(complex a,complex b){
	complex c;
	c.x = a.x + b.x;
	c.y = a.y + b.y;
	return c;
}

complex sqr(complex a){
	complex c;
	c.x = a.x*a.x - a.y*a.y;
	c.y = 2*a.x*a.y;
	return c;
}

double mod(complex a){
	return sqrt(a.x*a.x + a.y*a.y);
}

int main()
{
    omp_set_num_threads(OMP_NUM_THREADS);

    complex c;
    c.x = -0.8;
    c.y = 0.156;

    int N = 200;
    int width = 500;

    FILE *file;
    file = fopen("out.pgm", "wb");
    fprintf(file, "P5\n");
    fprintf(file, "%d %d\n", width, width);
    fprintf(file, "255\n");

    for (int x = 0; x < width; x++)
    {
        complex z;
        for (int y = 0; y < width; y++)
        {
            z.x = x;
            z.y = y;

            for (int i = 1; i <= N; i++)
            {
                z.x = z.x * z.x + c.x;
                z.y = z.y * z.y + c.y;
            }
            if (z.x < 200 && z.y < 200)
            {
                fprintf(file, "255 ");
            } else
            {
                fprintf(file, "0 ");
            }
        }
        fprintf(file, "\n");
    }

    return 0;
}